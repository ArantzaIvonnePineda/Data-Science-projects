from flask import Flask, url_for, jsonify, request, json

import pickle
import numpy as np

# Para probarlo, ejecutar el siguiente comando en bash (borrar los #)
#
#curl -H "Content-type: application/json" -X POST http://localhost:5000/ -d '{"input":[[6.1, 3.0 , 4.6, 1.4],
#	[6.1, 2.9, 4.7, 1.4], 
#	[6.3, 2.9, 5.6, 1.8],
#	[4.6, 3.4, 1.4, 0.3],
#    [5.2, 2.7, 3.9, 1.4]]}'


with open("model_GB_default.pkl", "rb") as f:
     model = pickle.load(f)

app = Flask(__name__)

@app.route('/', methods=['POST']) 
def predict(): 
	if request.headers['Content-Type'] == 'application/json':
		input=request.json['input']
	results = {} 
	y_hat = model.predict(np.array(input))
	results['parameters']= input
	results['resultado'] = y_hat.tolist() 
	return jsonify(results)

if __name__ == '__main__':
    app.run()


