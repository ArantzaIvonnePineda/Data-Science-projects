walmart_data <- load()
