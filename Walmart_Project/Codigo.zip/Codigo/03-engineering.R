walmart_data <- add.variables(walmart_data)

walmart_data <- change_description(walmart_data)

walmart_data <- generate_groups(walmart_data)
