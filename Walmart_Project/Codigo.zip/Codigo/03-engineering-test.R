walmart_test <- add.variables.test(walmart_test)

walmart_test <- change_description_test(walmart_test)

walmart_test <- generate_groups_test(walmart_test)