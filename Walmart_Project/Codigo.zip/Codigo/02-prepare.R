colnames(walmart_data) <- walmart_colnames


