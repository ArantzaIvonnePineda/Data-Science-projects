direc <- "./"

source(paste(direc,"utils.R", sep=''))
source(paste(direc,"01-load.R", sep=''))
source(paste(direc,"02-clean.R", sep=''))
source(paste(direc,"03-engineering.R", sep=''))
source(paste(direc,"04-save-train.R", sep=''))

source(paste(direc,"01-load-test.R", sep=''))
source(paste(direc,"02-clean-test.R", sep=''))
source(paste(direc,"03-engineering-test.R", sep=''))
source(paste(direc,"04-save-train-test.R", sep=''))